function switchTab(tab) {
  var tabs = ['copy','seo','corp','script','email','strategy'];
  tabs.forEach(function(t){
    var btn = document.getElementById('tbtn-'+t);
    var pane = document.getElementById('tab-'+t);
    if(t===tab){
      btn.style.background='var(--ink)'; btn.style.color='var(--gold)';
      pane.style.display='grid';
    } else {
      btn.style.background='var(--sand)'; btn.style.color='var(--muted)';
      pane.style.display='none';
    }
  });
}

  // Scroll reveal
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
  }, { threshold: 0.08 });
  document.querySelectorAll('.reveal').forEach(el => obs.observe(el));

  // Nav shadow on scroll
  const nav = document.getElementById('main-nav');
  window.addEventListener('scroll', () => {
    nav.style.boxShadow = window.scrollY > 50 ? '0 1px 12px rgba(0,0,0,0.07)' : 'none';
  });